#include "mbed.h"
#include "tsi_sensor.h"

/* This defines will be replaced by PinNames soon */
#if defined (TARGET_KL25Z) || defined (TARGET_KL46Z)
  #define ELEC0 9
  #define ELEC1 10
#elif defined (TARGET_KL05Z)
  #define ELEC0 9
  #define ELEC1 8
#else
  #error TARGET NOT DEFINED
#endif

int main(void) {
    PwmOut led1(LED_GREEN);
    PwmOut led2(LED_RED);
    PwmOut led3(LED_BLUE);
    TSIAnalogSlider tsi(ELEC0, ELEC1, 40);
    
    while (true) {
        float percen = tsi.readPercentage();
        if(percen <= 0.33 && percen >= 0.01){
            led1 = 1.0 - (0.25 * (percen * 3));
            led2 = 0.75 + (0.25 * ((percen) * 3));
            led3 = 1.0;
        }
        else if(percen > 0.33 && percen <= 0.66){
            led1 = 0.75 + (0.25 * ((percen - 0.33) * 3));
            led2 = 1.0;
            led3 = 1.0 - (0.25 * ((percen - 0.33) * 3));
        }
        else if(percen > 0.66 && percen <= 1.0){
            led1 = 1.0;
            led2 = 1.0 - (0.25 * ((percen - 0.66) * 3));
            led3 = 0.75 + (0.25 * ((percen - 0.66) * 3));
        }
        else{
            //all off aka 0.0
            led1 = 1.0;
            led2 = 1.0;
            led3  =1.0;
        }
        //led1 = 1.0 - (0.25 * percen);
        //led2 = 1.0;
        wait(0.1);
    }
}
